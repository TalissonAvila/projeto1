# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['client']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'client',
    'version': '0.1.0',
    'description': 'client side to send files to server',
    'long_description': '',
    'author': 'Talisson Avila',
    'author_email': 'devtalisson@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
