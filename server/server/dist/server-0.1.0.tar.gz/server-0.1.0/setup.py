# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['server']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'server',
    'version': '0.1.0',
    'description': 'server side to receive files from a client',
    'long_description': '',
    'author': 'Talisson Avila',
    'author_email': 'devtalisson@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
